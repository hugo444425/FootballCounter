package com.example.android.footballcounter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int scoreTeamA = 0;
    int scoreTeamB = 0;
    int foulsTeamA = 0;
    int foulsTeamB = 0;
    int yellowCardsTeamA = 0;
    int yellowCardsTeamB = 0;
    int redCardsTeamA = 0;
    int redCardsTeamB = 0;
    int offsidesTeamA = 0;
    int offsidesTeamB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     *
     * Methods for adding values to resources to Team A (Scores, fouls, cards and offsides)
     */
    public void addGoalForTeamA (View view){
        scoreTeamA = scoreTeamA + 1;
        displayForTeamA(scoreTeamA, R.id.team_a_score);
    }

    public void addFoulsForTeamA (View view){
        foulsTeamA = foulsTeamA + 1;
        displayForTeamA(foulsTeamA, R.id.team_a_fouls);
    }

    public void addYellowCardForTeamA (View view){
        yellowCardsTeamA = yellowCardsTeamA + 1;
        displayForTeamA(yellowCardsTeamA, R.id.team_a_yellow_card);
    }

    public void addRedCardForTeamA (View view){
        redCardsTeamA = redCardsTeamA + 1;
        displayForTeamA(redCardsTeamA, R.id.team_a_red_card);
    }

    public void addOffsidesForTeamA (View view){
        offsidesTeamA = offsidesTeamA + 1;
        displayForTeamA(offsidesTeamA, R.id.team_a_offsides);
    }

    /**
     *
     * Methods for adding values to resources to Team B (Scores, fouls, cards and offsides)
     */

    public void addGoalForTeamB (View view){
        scoreTeamB = scoreTeamB + 1;
        displayForTeamB(scoreTeamB, R.id.team_b_score);
    }

    public void addFoulsForTeamB (View view){
        foulsTeamB = foulsTeamB + 1;
        displayForTeamB(foulsTeamB, R.id.team_b_fouls);
    }

    public void addYellowCardForTeamB (View view){
        yellowCardsTeamB = yellowCardsTeamB + 1;
        displayForTeamB(yellowCardsTeamB, R.id.team_b_yellow_card);
    }

    public void addRedCardForTeamB (View view){
        redCardsTeamB = redCardsTeamB + 1;
        displayForTeamB(redCardsTeamB, R.id.team_b_red_card);
    }

    public void addOffsidesForTeamB (View view){
        offsidesTeamB = offsidesTeamB + 1;
        displayForTeamB(offsidesTeamB, R.id.team_b_offsides);
    }

    /**
     *
     * Reset scores, cards, fouls and offsides
     */

    public void resetScores(View view){
        scoreTeamA = 0;
        scoreTeamB = 0;
        foulsTeamA = 0;
        foulsTeamB = 0;
        yellowCardsTeamA = 0;
        yellowCardsTeamB = 0;
        redCardsTeamA = 0;
        redCardsTeamB = 0;
        offsidesTeamA = 0;
        offsidesTeamB = 0;

        displayForTeamA(scoreTeamA, R.id.team_a_score);
        displayForTeamA(foulsTeamA, R.id.team_a_fouls);
        displayForTeamA(yellowCardsTeamA, R.id.team_a_yellow_card);
        displayForTeamA(redCardsTeamA, R.id.team_a_red_card);
        displayForTeamA(offsidesTeamA, R.id.team_a_offsides);

        displayForTeamB(scoreTeamB, R.id.team_b_score);
        displayForTeamB(foulsTeamB, R.id.team_b_fouls);
        displayForTeamB(yellowCardsTeamB, R.id.team_b_yellow_card);
        displayForTeamB(redCardsTeamB, R.id.team_b_red_card);
        displayForTeamB(offsidesTeamB, R.id.team_b_offsides);
    }
    /**
     * Displays the given resource for Team A.
     */
    public void displayForTeamA(int score, int resource) {
        TextView scoreView = (TextView) findViewById(resource);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * Displays the given variable for Team B.
     */
    public void displayForTeamB(int score, int resource) {
        TextView scoreView = (TextView) findViewById(resource);
        scoreView.setText(String.valueOf(score));
    }
}
